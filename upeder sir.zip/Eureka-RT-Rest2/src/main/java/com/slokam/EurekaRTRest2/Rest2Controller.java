package com.slokam.EurekaRTRest2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Rest2Controller {

	@RequestMapping("getRest2")
	public String getStudent(){
		return " Iam from slokam Tech...";
	}
}
