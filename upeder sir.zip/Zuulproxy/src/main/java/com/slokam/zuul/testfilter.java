package com.slokam.zuul;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;

@Component
public class testfilter extends ZuulFilter {

	public Object run() {
		System.out.println("test test test test");
		return null;
	}

	public boolean shouldFilter() {
		return true;
	}

	@Override
	public int filterOrder() {
		return 1;
	}

	@Override
	public String filterType() {
		return "pre";
	}
}