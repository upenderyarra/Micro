package com.slk.feign;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
public class Client1Controller {

	@RequestMapping("getData")
	@HystrixCommand(fallbackMethod="getFallBackData")
	public Data getStudent(){
		if(true){
			throw new RuntimeException();
		}
		Data std = new Data();
		std.setId(1);
		std.setAge(12);
		std.setName("Name1 6/1/2017");
		std.setQual("B.Tech");
		return std;
	}
	
	public Data getFallBackData(){
		Data dd = new Data();
		dd.setId(99);
		dd.setName("Fall Back name");
		dd.setAge(88);
		dd.setQual("Fall Back Qual");
		return dd;
	}
}
