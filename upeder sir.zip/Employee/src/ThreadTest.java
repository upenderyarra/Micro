import java.util.Iterator;
import java.util.List;

public class ThreadTest extends Thread {
	List<String> lis =null;
	

	public ThreadTest(List<String> lis) {
	this.lis=lis;	
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	Iterator<String> It=lis.iterator();
	
	while (It.hasNext()) {
		System.out.println(Thread.currentThread().getName()+":"+It.next());
		//It.remove();
		
	}
		
		
		
	}
}
