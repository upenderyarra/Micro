import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

public class Empoyee  implements Comparator<Empoyee>{
	
	
	public int id12;
	public String name123;
	public String  des;
	public String  des1;
	
	
	/*@Override
	public int compareTo(Empoyee arg0) {
		if(this.id12==arg0.id12){
			return 0;
		}
		if(this.id12 < arg0.id12){
			return -1;
			
		}
		else 
			return 1;
			
		}
	
	*/
	
	@Override
	public int compare(Empoyee arg0, Empoyee arg1) {
		if(arg0.id12==arg0.id12){
			return 0;
		}
		if(arg0.id12 < arg0.id12){
			return -1;
			
		}
		else 
			return 1;
			
		}
	





	public Empoyee(int id12, String name123, String des, String des1) {
		super();
		this.id12 = id12;
		this.name123 = name123;
		this.des = des;
		this.des1 = des1;
	}

	
	


	@Override
	public String toString() {
		return "Empoyee [id12=" + id12 + ", name123=" + name123 + ", des=" + des + ", des1=" + des1 + "]";
	}



	public static void main(String[] args) {
		Set<Empoyee> s=new TreeSet<Empoyee>();
		
		Empoyee e1=new Empoyee(100, "upender", "des", "des1");
		Empoyee e2=new Empoyee(110, "upender", "des", "des1");
		Empoyee e3=new Empoyee(108, "upender", "des", "des1");
		Empoyee e4=new Empoyee(101, "upender", "des", "des1");
		s.add(e1);
		s.add(e2);
		s.add(e3);
		s.add(e4);
		//s.add(e1);
		
		for (Empoyee empoyee : s) {
			System.out.println(empoyee);
		}
		
		
	}
	
	}
	
	
	
	


