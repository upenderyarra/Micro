import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class concurentmodification {
	
	public static void main(String[] args) {
	
		List<String> lis=new ArrayList<>();
		lis.add("1");
		lis.add("2");
		lis.add("3");
		lis.add("4");
		//Collections.synchronizedList(lis);
		ThreadTest test=new ThreadTest(lis);
		test.start();
		
	Iterator<String> it=lis.iterator();
	
	while (it.hasNext()) {
		System.out.println(Thread.currentThread().getName()+":"+it.next());
		
		//concorentmodification exception
		lis.remove("4");   
		//it.remove();
		
		
	}
		

		
	}
	
}
