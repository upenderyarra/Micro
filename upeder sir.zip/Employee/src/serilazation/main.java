package serilazation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class main {

	public static void main(String[] args) {
		//NotSerializableException - if class is not implements serilazation . 
		//java.io.InvalidClassException:-  after few days if i modify student object ,when we try to deserilazation the object we will get the InvalidClassException 
		//to over come above problem we need to maintain the serialVersionUID 
		
//		serilazation();

		deSerilazation();
}
	static void deSerilazation(){
		
		try {
			
			FileInputStream fis=new FileInputStream("e:ser.text");
			ObjectInputStream ois=new ObjectInputStream(fis);
			Student s=	(Student)ois.readObject();
			System.out.println(s);
	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	static  void  serilazation(){
		Student s = new Student(10, "name", "des");

		FileOutputStream fos;
		try {
			fos = new FileOutputStream("e:ser.text");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(s);
			
			System.out.println("serilazation completed sucessfuly");
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
}