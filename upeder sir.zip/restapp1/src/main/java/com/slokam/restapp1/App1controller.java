package com.slokam.restapp1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class App1controller {
	
	@RequestMapping("getappdata")
	public Data getappdata(){
		Data d=new Data();
		d.setId(1);
		d.setName("shiva");
		d.setDesc("description");
		return d;
	}
}
