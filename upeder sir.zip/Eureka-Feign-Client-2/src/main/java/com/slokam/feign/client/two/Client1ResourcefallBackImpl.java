package com.slokam.feign.client.two;

import org.springframework.stereotype.Component;

@Component
public class Client1ResourcefallBackImpl implements Client1Resource{

	@Override
	public Data getData() {
		Data dat = new Data();
		dat.setId(0);
		dat.setName("FallBackName...Dummy");
		dat.setAge(0);
		dat.setQual(" ITBT Client1ResourcefallBackImpl....");
		return dat;
	}
}
