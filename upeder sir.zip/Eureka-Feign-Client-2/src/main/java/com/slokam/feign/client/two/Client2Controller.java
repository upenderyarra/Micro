package com.slokam.feign.client.two;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Client2Controller {

	@Autowired
	private Client1Resource c1r;
	
	@RequestMapping("getDataOfData")
	public Data2OfData getStudent(){
		Data2OfData d2od = new Data2OfData();
		d2od.setId(2);
		d2od.setAge(12);
		d2od.setName("Name2 01/08/2017  Client2 Controller.....");
		d2od.setQual("MCA  get DataOfData...");
	
		Data data = c1r.getData();
		d2od.setDt(data);
		return d2od;
	}
}