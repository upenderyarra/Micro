package com.slokam.feign.client.two;

import org.springframework.stereotype.Component;

@Component
public class Client1ResourcefallBackImpl implements Client1Resource{

	@Override
	public Data getData() {
		Data dat = new Data();
		dat.setId(0);
		dat.setName("FallBackName1234 Client2");
		dat.setAge(100);
		dat.setQual(" Client1ResourcefallBackImpl... Dummy");
		return dat;
	}
}
