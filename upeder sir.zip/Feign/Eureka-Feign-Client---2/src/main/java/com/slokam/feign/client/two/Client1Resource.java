package com.slokam.feign.client.two;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(value="http://FEIGN-CLIENT-ONE-BAVA",fallback=Client1ResourcefallBackImpl.class)
public interface Client1Resource {

	@RequestMapping("/getData")
	public Data getData();
}
