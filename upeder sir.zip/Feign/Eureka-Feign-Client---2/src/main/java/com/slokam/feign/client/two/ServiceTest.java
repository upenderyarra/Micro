package com.slokam.feign.client.two;

import org.springframework.stereotype.Service;

@Service
public class ServiceTest {
  
	public String test(){
	  return "Data";
  }
}
