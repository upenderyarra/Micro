package com.slokam.Rest1LB;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Rest1Controller {

	@Autowired
	private RestTemplate rt;
	
	@RequestMapping("getRest1LB")
	public String getStudent(){
		ResponseEntity<String> re= rt.getForEntity("http://LB-Rest2/getRest2Lb", String.class);
		return " Iam from slokam Tech... Load Bal....."+ re;
	}
}
