package com.slokam.loadblnc2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Rest2Controller {

	@RequestMapping("getRest2Lb")
	public String getStudent(){
		return " Iam from Load Balancer";
	}
}
