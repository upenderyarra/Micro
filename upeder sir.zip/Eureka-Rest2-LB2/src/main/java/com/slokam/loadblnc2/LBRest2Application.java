package com.slokam.loadblnc2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class LBRest2Application {

	public static void main(String[] args) {
		SpringApplication.run(LBRest2Application.class, args);
	}
}
