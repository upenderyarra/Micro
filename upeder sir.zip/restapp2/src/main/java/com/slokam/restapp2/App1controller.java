package com.slokam.restapp2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class App1controller {
	
	@RequestMapping("getapp2data")
	public Data getappdata() {
		Data d = new Data();
		d.setId(2);
		d.setName("shivasaii");
		d.setDesc("descriptionrestapp2");
		return d;
	}
}
