package com.slokam.ConfigClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {
	
	@Value("${data}")
	private String data;
	
	@Value("${key}")
	private String key;

	@RequestMapping("getData")
	public String getData(){
		return data+"::"+key;
	}
}
