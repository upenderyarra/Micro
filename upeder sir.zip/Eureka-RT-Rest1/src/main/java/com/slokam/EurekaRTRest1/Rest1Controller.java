package com.slokam.EurekaRTRest1;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Rest1Controller {

	@RequestMapping("getRest1")
	public String getStudent(){
		RestTemplate rt = new RestTemplate();
		ResponseEntity<String> re= rt.getForEntity("http://localhost:7777/getRest2", String.class);
		return "Hello I am at controller 1...." + re;
	}
}
